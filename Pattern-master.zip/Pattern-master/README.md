# Pattern
pedestrain and non pedestrain pattern recognation using : knn , svm , CNN
